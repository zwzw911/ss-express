/**
 * Created by wzhan039 on 2015-07-20.
 */
var server={

    host:'localhost:3000'
};