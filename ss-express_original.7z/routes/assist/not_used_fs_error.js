/**
 * Created by wzhan039 on 2015-07-14.
 * Define filesystem error
 */


var fsErrorMsg={200:'目标文件夹不存在',
    201:'文件夹空间不够'
}

exports.fsErrorMsg=fsErrorMsg;
