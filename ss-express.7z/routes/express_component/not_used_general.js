/**
 * Created by wzhan039 on 2015-07-30.
 */

var genHash=function(str){
    var date=new Date().getTime();

}
